# Corrected Linear Leios vote study

Updated 2026-09-15T13:40:49+00:00. **10/10 runs completed and parsed.**

Simulator `825982b42e519184b5fd890298662ab29797f091`; upstream config `f307ed5fa7077a32eb470ca3832a34092882bfe3`.

Run lengths are recorded in runs.csv; configuration and topology bytes are preserved alongside the logs. This extraction verifies the input and log checksums. Quorum deadlines are read from each final summary.

**Interpretation:** this is simulator evidence. Pending/failed runs are excluded. Q95 times are means of per-EB times when nodes holding 95% of network stake each have a quorum, conditional on attainment. Fixed end-of-run truncation can leave the newest EBs unfinished. Equal endorsement counts do not establish identical EB identities. Vote-credit and header approximations limit transfer to Haskell.

| Nodes | Stake pools | Eligible in fixed-size arm | Stake coverage | Links |
|---:|---:|---:|---:|---:|
| 1500 | 458 | 458 | 100.0% | 39526 |

## Completed runs

`stake` = top-stake-seats; `all-nodes` = everyone. Traffic is decimal GB, rounded in the simulator log. Q95 means nodes collectively holding 95% of network stake each have a quorum. This receiving-node percentage is separate from the 75% voting threshold for a certificate.

| Nodes | Committee | Seed | Transport | Fanout | Protect BP | Announce/request B | EBs | L1 endorsements | Q95 reached | Q95 by vote deadline | Q95 mean s | Wire GB | Verify/accepted | Pending | Runtime min |
|---:|---|---:|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1500 | stake | 0 | push | 22 | false | 8/8 | 26 | 7 | 0/26 | 0/26 | — | 19.470 | 1.00 | 0 | 18.6 |
| 1500 | stake | 0 | push | 22 | true | 8/8 | 26 | 8 | 20/26 | 20/26 | 3.335 | 19.621 | 1.00 | 0 | 18.9 |
| 1500 | stake | 0 | push | 16 | false | 8/8 | 26 | 1 | 0/26 | 0/26 | — | 14.194 | 1.00 | 0 | 16.7 |
| 1500 | stake | 0 | push | 16 | true | 8/8 | 26 | 8 | 20/26 | 20/26 | 3.338 | 14.375 | 1.00 | 0 | 18.1 |
| 1500 | stake | 0 | push | 8 | false | 8/8 | 26 | 0 | 0/26 | 0/26 | — | 7.097 | 1.00 | 0 | 16.8 |
| 1500 | stake | 0 | push | 8 | true | 8/8 | 26 | 8 | 20/26 | 20/26 | 3.345 | 7.380 | 1.00 | 0 | 17.3 |
| 1500 | stake | 0 | announce-then-request | all | false | 8/8 | 26 | 8 | 20/26 | 20/26 | 3.850 | 4.149 | 1.00 | 0 | 20.7 |
| 1500 | stake | 0 | announce-then-request | all | false | 40/40 | 26 | 8 | 20/26 | 20/26 | 3.850 | 15.715 | 1.00 | 0 | 19.8 |
| 1500 | stake | 0 | announce-then-request | all | false | 64/64 | 26 | 8 | 20/26 | 20/26 | 3.850 | 24.390 | 1.00 | 0 | 20.2 |
| 1500 | stake | 0 | push | all | false | 8/8 | 26 | 8 | 20/26 | 20/26 | 3.334 | 32.684 | 1.00 | 0 | 23.3 |

## Obsolete vote work

These are subsets of the existing CPU and wire totals, not additional costs. Obsolete means every EB in the bundle was locally pruned at the measured phase. A vote can become obsolete between arrival and completion. First/repeat verification counts refer to prior completed processing at the same node; a cache reinsertion is a repeat completion with no held copy before insertion. Metrics missing from older logs are unmeasured, not zero.

| Run | Obsolete arrivals | After prior processing | Obsolete checks | First | Repeat | Cache reinsertions | Bodies sent | Announcements sent |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 1500-top-stake-seats-push-f22-bpfalse-a8-r8-s0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1500-top-stake-seats-push-f22-bptrue-a8-r8-s0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1500-top-stake-seats-push-f16-bpfalse-a8-r8-s0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1500-top-stake-seats-push-f16-bptrue-a8-r8-s0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1500-top-stake-seats-push-f8-bpfalse-a8-r8-s0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1500-top-stake-seats-push-f8-bptrue-a8-r8-s0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1500-top-stake-seats-announce-then-request-fall-bpfalse-a8-r8-s0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1500-top-stake-seats-announce-then-request-fall-bpfalse-a40-r40-s0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1500-top-stake-seats-announce-then-request-fall-bpfalse-a64-r64-s0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 1500-top-stake-seats-push-fall-bpfalse-a8-r8-s0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

Full numeric data and paired comparisons: [results.json](results.json). Inputs, overlays and summary logs are retained beside this report.
