# Per-node vote traffic

Duration: 400 simulated seconds. Decimal GB/MB and Mbit/s. BP means a stake-holding node in a topology that separates BPs from relays.

Traffic includes duplicate bodies plus vote announcements and requests. Sends are recorded when queued; receives when delivered. No TCP/IP framing or other protocols are included. Peaks are the busiest fixed one-second buckets aligned to simulation time zero, not instantaneous or sliding-window link throughput. A per-node send peak sums all its outgoing links.

| Role | Nodes | Sent GB | Received GB | Median sent MB/node | p95 sent MB/node | Max sent MB/node |
|---|---:|---:|---:|---:|---:|---:|
| BP | 458 | 0.385164 | 0.568619 | 0.841 | 0.841 | 0.841 |
| relay | 1042 | 6.994522 | 6.811068 | 6.713 | 6.713 | 6.713 |
| all | 1500 | 7.379686 | 7.379686 | 6.713 | 6.713 | 6.713 |

Percentiles below are across nodes, using each node’s own busiest one-second window. Nodes can peak at different times.

| Role | Median node peak sent Mbit/s | p95 | Max | Median node peak received Mbit/s | p95 | Max |
|---|---:|---:|---:|---:|---:|---:|
| BP | 0.333 | 0.333 | 0.333 | 0.500 | 0.538 | 0.556 |
| relay | 2.659 | 2.659 | 2.659 | 2.607 | 3.324 | 3.886 |
| all | 2.659 | 2.659 | 2.659 | 2.371 | 3.274 | 3.886 |

The [per-node CSV](nodes.csv) includes separate body/control counts, sent/received totals, mean rates, and each peak’s window start. Raw JSON retains every node’s one-second buckets.
