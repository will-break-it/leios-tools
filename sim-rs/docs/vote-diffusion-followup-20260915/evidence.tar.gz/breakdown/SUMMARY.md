# Focused vote diffusion comparison

1500 nodes, 458 stake pools, top-stake-seats, 400 slots; seeds: 0.

Traffic is exact decimal GB from per-node captures and includes vote bodies, announcements and requests. It excludes TCP/IP. The 40/40 and 64/64 byte cases are sensitivity assumptions, not verified encodings. Q95 means quorum availability at nodes holding 95% of stake; each node needs 75% of total voting stake. Timing means are conditional on attainment and may cover different EBs. Newest EBs may be unfinished at the fixed cutoff.

## Availability and traffic

Protected BP links take places within the total fanout cap. Protecting one BP under cap 22 leaves 21 places for other consumers.

| Seed | Transport | Cap | Protect BP | Announce/request B | EBs | Q50 | Q95 | Q95 by 7s | Q95 mean s | Endorsements | Bundles at 95% of nodes | Wire GB |
|---:|---|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | push | 22 | false | 8/8 | 26 | 20/26 | 0/26 | 0/26 | n/a | 7 | 8876/8877 | 19.469734 |
| 0 | push | 22 | true | 8/8 | 26 | 20/26 | 20/26 | 20/26 | 3.335 | 8 | 8927/8927 | 19.621395 |
| 0 | push | 16 | false | 8/8 | 26 | 0/26 | 0/26 | 0/26 | n/a | 1 | 0/8877 | 14.194184 |
| 0 | push | 16 | true | 8/8 | 26 | 20/26 | 20/26 | 20/26 | 3.338 | 8 | 8927/8927 | 14.375273 |
| 0 | push | 8 | false | 8/8 | 26 | 0/26 | 0/26 | 0/26 | n/a | 0 | 0/8850 | 7.096878 |
| 0 | push | 8 | true | 8/8 | 26 | 20/26 | 20/26 | 20/26 | 3.345 | 8 | 8927/8927 | 7.379686 |
| 0 | announce-then-request | all | false | 8/8 | 26 | 20/26 | 20/26 | 20/26 | 3.850 | 8 | 8927/8927 | 4.149362 |
| 0 | announce-then-request | all | false | 40/40 | 26 | 20/26 | 20/26 | 20/26 | 3.850 | 8 | 8927/8927 | 15.715349 |
| 0 | announce-then-request | all | false | 64/64 | 26 | 20/26 | 20/26 | 20/26 | 3.850 | 8 | 8927/8927 | 24.389794 |
| 0 | push | all | false | 8/8 | 26 | 20/26 | 20/26 | 20/26 | 3.334 | 8 | 8927/8927 | 32.684092 |

## Control-size sensitivity

The same unrestricted push case is the baseline for all three pull cases because it sends no control messages. These ratios use executed simulations, not a repricing of fixed message counts.

| Seed | Pull announce/request B | Push / pull bytes | Push Q95 mean advantage s |
|---:|---|---:|---:|
| 0 | 8/8 | 7.877 | 0.516 |
| 0 | 40/40 | 2.080 | 0.516 |
| 0 | 64/64 | 1.340 | 0.516 |

## Message counts and verification

Obsolete checks are a subset of total checks, measured when completion occurs after local EB pruning. They are not subtracted from the reported cost. Missing metrics are unmeasured, not zero.

| Run | Sent bodies | Announcements | Requests | Bodies GB | Announcements GB | Requests GB | Checks / accepted | Obsolete checks |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 1500-top-stake-seats-push-f22-bpfalse-a8-r8-s0 | 207124833 | 0 | 0 | 19.469734 | 0.000000 | 0.000000 | 1.000 | 0 |
| 1500-top-stake-seats-push-f22-bptrue-a8-r8-s0 | 208738244 | 0 | 0 | 19.621395 | 0.000000 | 0.000000 | 1.000 | 0 |
| 1500-top-stake-seats-push-f16-bpfalse-a8-r8-s0 | 151001958 | 0 | 0 | 14.194184 | 0.000000 | 0.000000 | 1.000 | 0 |
| 1500-top-stake-seats-push-f16-bptrue-a8-r8-s0 | 152928437 | 0 | 0 | 14.375273 | 0.000000 | 0.000000 | 1.000 | 0 |
| 1500-top-stake-seats-push-f8-bpfalse-a8-r8-s0 | 75498701 | 0 | 0 | 7.096878 | 0.000000 | 0.000000 | 1.000 | 0 |
| 1500-top-stake-seats-push-f8-bptrue-a8-r8-s0 | 78507301 | 0 | 0 | 7.379686 | 0.000000 | 0.000000 | 1.000 | 0 |
| 1500-top-stake-seats-announce-then-request-fall-bpfalse-a8-r8-s0 | 13381573 | 348055165 | 13381573 | 1.257868 | 2.784441 | 0.107053 | 1.000 | 0 |
| 1500-top-stake-seats-announce-then-request-fall-bpfalse-a40-r40-s0 | 13381573 | 348055465 | 13381573 | 1.257868 | 13.922219 | 0.535263 | 1.000 | 0 |
| 1500-top-stake-seats-announce-then-request-fall-bpfalse-a64-r64-s0 | 13381573 | 348054769 | 13381573 | 1.257868 | 22.275505 | 0.856421 | 1.000 | 0 |
| 1500-top-stake-seats-push-fall-bpfalse-a8-r8-s0 | 347703105 | 0 | 0 | 32.684092 | 0.000000 | 0.000000 | 1.000 | 0 |

## Per-node distribution

Peaks are node totals across outgoing links in fixed one-second windows. These are queued sends, not instantaneous link throughput. The 10 Mbit/s limit applies to each link, not each node.

| Run | Role | Total sent GB | Median sent MB/node | p95 | Max | Median received MB/node | Median node peak sent Mbit/s | Max |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| [1500-top-stake-seats-push-f22-bpfalse-a8-r8-s0](1500-top-stake-seats-push-f22-bpfalse-a8-r8-s0/summary.md) | BP | 0.341243 | 0.763 | 0.808 | 0.836 | 1.043 | 0.307 | 0.333 |
| [1500-top-stake-seats-push-f22-bpfalse-a8-r8-s0](1500-top-stake-seats-push-f22-bpfalse-a8-r8-s0/summary.md) | relay | 19.128491 | 18.358 | 18.358 | 18.358 | 18.119 | 7.312 | 7.312 |
| [1500-top-stake-seats-push-f22-bptrue-a8-r8-s0](1500-top-stake-seats-push-f22-bptrue-a8-r8-s0/summary.md) | BP | 0.385164 | 0.841 | 0.841 | 0.841 | 1.478 | 0.333 | 0.333 |
| [1500-top-stake-seats-push-f22-bptrue-a8-r8-s0](1500-top-stake-seats-push-f22-bptrue-a8-r8-s0/summary.md) | relay | 19.236231 | 18.461 | 18.461 | 18.461 | 18.024 | 7.312 | 7.312 |
| [1500-top-stake-seats-push-f16-bpfalse-a8-r8-s0](1500-top-stake-seats-push-f16-bpfalse-a8-r8-s0/summary.md) | BP | 0.282435 | 0.635 | 0.693 | 0.736 | 0.762 | 0.259 | 0.299 |
| [1500-top-stake-seats-push-f16-bpfalse-a8-r8-s0](1500-top-stake-seats-push-f16-bpfalse-a8-r8-s0/summary.md) | relay | 13.911749 | 13.351 | 13.351 | 13.351 | 13.212 | 5.318 | 5.318 |
| [1500-top-stake-seats-push-f16-bptrue-a8-r8-s0](1500-top-stake-seats-push-f16-bptrue-a8-r8-s0/summary.md) | BP | 0.385164 | 0.841 | 0.841 | 0.841 | 1.418 | 0.333 | 0.333 |
| [1500-top-stake-seats-push-f16-bptrue-a8-r8-s0](1500-top-stake-seats-push-f16-bptrue-a8-r8-s0/summary.md) | relay | 13.990109 | 13.426 | 13.426 | 13.426 | 13.057 | 5.318 | 5.318 |
| [1500-top-stake-seats-push-f8-bpfalse-a8-r8-s0](1500-top-stake-seats-push-f8-bpfalse-a8-r8-s0/summary.md) | BP | 0.164011 | 0.370 | 0.418 | 0.465 | 0.386 | 0.159 | 0.191 |
| [1500-top-stake-seats-push-f8-bpfalse-a8-r8-s0](1500-top-stake-seats-push-f8-bpfalse-a8-r8-s0/summary.md) | relay | 6.932867 | 6.654 | 6.655 | 6.655 | 6.593 | 2.659 | 2.659 |
| [1500-top-stake-seats-push-f8-bptrue-a8-r8-s0](1500-top-stake-seats-push-f8-bptrue-a8-r8-s0/summary.md) | BP | 0.385164 | 0.841 | 0.841 | 0.841 | 1.240 | 0.333 | 0.333 |
| [1500-top-stake-seats-push-f8-bptrue-a8-r8-s0](1500-top-stake-seats-push-f8-bptrue-a8-r8-s0/summary.md) | relay | 6.994522 | 6.713 | 6.713 | 6.713 | 6.507 | 2.659 | 2.659 |
| [1500-top-stake-seats-announce-then-request-fall-bpfalse-a8-r8-s0](1500-top-stake-seats-announce-then-request-fall-bpfalse-a8-r8-s0/summary.md) | BP | 0.079317 | 0.165 | 0.226 | 0.334 | 0.980 | 0.066 | 0.133 |
| [1500-top-stake-seats-announce-then-request-fall-bpfalse-a8-r8-s0](1500-top-stake-seats-announce-then-request-fall-bpfalse-a8-r8-s0/summary.md) | relay | 4.070045 | 3.173 | 8.512 | 23.078 | 3.550 | 1.257 | 9.144 |
| [1500-top-stake-seats-announce-then-request-fall-bpfalse-a40-r40-s0](1500-top-stake-seats-announce-then-request-fall-bpfalse-a40-r40-s0/summary.md) | BP | 0.340966 | 0.736 | 0.797 | 0.907 | 1.551 | 0.292 | 0.360 |
| [1500-top-stake-seats-announce-then-request-fall-bpfalse-a40-r40-s0](1500-top-stake-seats-announce-then-request-fall-bpfalse-a40-r40-s0/summary.md) | relay | 15.374384 | 12.501 | 25.791 | 72.721 | 14.398 | 4.920 | 28.800 |
| [1500-top-stake-seats-announce-then-request-fall-bpfalse-a64-r64-s0](1500-top-stake-seats-announce-then-request-fall-bpfalse-a64-r64-s0/summary.md) | BP | 0.537250 | 1.164 | 1.226 | 1.333 | 1.980 | 0.461 | 0.528 |
| [1500-top-stake-seats-announce-then-request-fall-bpfalse-a64-r64-s0](1500-top-stake-seats-announce-then-request-fall-bpfalse-a64-r64-s0/summary.md) | relay | 23.852544 | 19.341 | 39.131 | 109.981 | 22.530 | 7.607 | 43.552 |
| [1500-top-stake-seats-push-fall-bpfalse-a8-r8-s0](1500-top-stake-seats-push-fall-bpfalse-a8-r8-s0/summary.md) | BP | 0.385164 | 0.841 | 0.841 | 0.841 | 1.581 | 0.333 | 0.333 |
| [1500-top-stake-seats-push-fall-bpfalse-a8-r8-s0](1500-top-stake-seats-push-fall-bpfalse-a8-r8-s0/summary.md) | relay | 32.298928 | 25.970 | 52.622 | 153.114 | 30.577 | 10.287 | 60.649 |

Each linked report includes received-byte and peak-rate percentiles, with a per-node CSV. The machine-readable [followup.json](followup.json) includes exact totals, all protocol metrics and obsolete-work subsets.

## Archived default comparison

Matching unprotected 8/8 cases are compared with the original 400-slot runs. Checks include quorum counts/times, endorsements, vote generation, body delivery, verification and wire totals. Wall-clock runtime and newly added instrumentation are excluded.

| Run | Compared protocol metrics |
|---|---|
| 1500-top-stake-seats-push-f22-bpfalse-a8-r8-s0 | All equal |
| 1500-top-stake-seats-push-f16-bpfalse-a8-r8-s0 | All equal |
| 1500-top-stake-seats-push-f8-bpfalse-a8-r8-s0 | All equal |
| 1500-top-stake-seats-announce-then-request-fall-bpfalse-a8-r8-s0 | All equal |
| 1500-top-stake-seats-push-fall-bpfalse-a8-r8-s0 | All equal |
