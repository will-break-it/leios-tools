# Per-node vote traffic

Duration: 400 simulated seconds. Decimal GB/MB and Mbit/s. BP means a stake-holding node in a topology that separates BPs from relays.

Traffic includes duplicate bodies plus vote announcements and requests. Sends are recorded when queued; receives when delivered. No TCP/IP framing or other protocols are included. Peaks are the busiest fixed one-second buckets aligned to simulation time zero, not instantaneous or sliding-window link throughput. A per-node send peak sums all its outgoing links.

| Role | Nodes | Sent GB | Received GB | Median sent MB/node | p95 sent MB/node | Max sent MB/node |
|---|---:|---:|---:|---:|---:|---:|
| BP | 458 | 0.164011 | 0.170813 | 0.370 | 0.418 | 0.465 |
| relay | 1042 | 6.932867 | 6.926065 | 6.654 | 6.655 | 6.655 |
| all | 1500 | 7.096878 | 7.096878 | 6.654 | 6.655 | 6.655 |

Percentiles below are across nodes, using each node’s own busiest one-second window. Nodes can peak at different times.

| Role | Median node peak sent Mbit/s | p95 | Max | Median node peak received Mbit/s | p95 | Max |
|---|---:|---:|---:|---:|---:|---:|
| BP | 0.159 | 0.179 | 0.191 | 0.166 | 0.190 | 0.212 |
| relay | 2.659 | 2.659 | 2.659 | 2.659 | 3.416 | 4.027 |
| all | 2.659 | 2.659 | 2.659 | 2.413 | 3.358 | 4.027 |

The [per-node CSV](nodes.csv) includes separate body/control counts, sent/received totals, mean rates, and each peak’s window start. Raw JSON retains every node’s one-second buckets.
