# Per-node vote traffic

Duration: 400 simulated seconds. Decimal GB/MB and Mbit/s. BP means a stake-holding node in a topology that separates BPs from relays.

Traffic includes duplicate bodies plus vote announcements and requests. Sends are recorded when queued; receives when delivered. No TCP/IP framing or other protocols are included. Peaks are the busiest fixed one-second buckets aligned to simulation time zero, not instantaneous or sliding-window link throughput. A per-node send peak sums all its outgoing links.

| Role | Nodes | Sent GB | Received GB | Median sent MB/node | p95 sent MB/node | Max sent MB/node |
|---|---:|---:|---:|---:|---:|---:|
| BP | 458 | 0.340966 | 0.710571 | 0.736 | 0.797 | 0.907 |
| relay | 1042 | 15.374384 | 15.004778 | 12.501 | 25.791 | 72.721 |
| all | 1500 | 15.715349 | 15.715349 | 11.545 | 22.215 | 72.721 |

Percentiles below are across nodes, using each node’s own busiest one-second window. Nodes can peak at different times.

| Role | Median node peak sent Mbit/s | p95 | Max | Median node peak received Mbit/s | p95 | Max |
|---|---:|---:|---:|---:|---:|---:|
| BP | 0.292 | 0.317 | 0.360 | 0.614 | 0.615 | 0.615 |
| relay | 4.920 | 10.180 | 28.800 | 5.404 | 6.464 | 7.706 |
| all | 4.528 | 8.599 | 28.800 | 5.002 | 6.361 | 7.706 |

The [per-node CSV](nodes.csv) includes separate body/control counts, sent/received totals, mean rates, and each peak’s window start. Raw JSON retains every node’s one-second buckets.
