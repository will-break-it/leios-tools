# Per-node vote traffic

Duration: 400 simulated seconds. Decimal GB/MB and Mbit/s. BP means a stake-holding node in a topology that separates BPs from relays.

Traffic includes duplicate bodies plus vote announcements and requests. Sends are recorded when queued; receives when delivered. No TCP/IP framing or other protocols are included. Peaks are the busiest fixed one-second buckets aligned to simulation time zero, not instantaneous or sliding-window link throughput. A per-node send peak sums all its outgoing links.

| Role | Nodes | Sent GB | Received GB | Median sent MB/node | p95 sent MB/node | Max sent MB/node |
|---|---:|---:|---:|---:|---:|---:|
| BP | 458 | 0.079317 | 0.448903 | 0.165 | 0.226 | 0.334 |
| relay | 1042 | 4.070045 | 3.700459 | 3.173 | 8.512 | 23.078 |
| all | 1500 | 4.149362 | 4.149362 | 2.782 | 6.199 | 23.078 |

Percentiles below are across nodes, using each node’s own busiest one-second window. Nodes can peak at different times.

| Role | Median node peak sent Mbit/s | p95 | Max | Median node peak received Mbit/s | p95 | Max |
|---|---:|---:|---:|---:|---:|---:|
| BP | 0.066 | 0.091 | 0.133 | 0.388 | 0.388 | 0.388 |
| relay | 1.257 | 3.368 | 9.144 | 1.346 | 1.555 | 1.807 |
| all | 1.093 | 2.453 | 9.144 | 1.264 | 1.537 | 1.807 |

The [per-node CSV](nodes.csv) includes separate body/control counts, sent/received totals, mean rates, and each peak’s window start. Raw JSON retains every node’s one-second buckets.
