# Per-node vote traffic

Duration: 400 simulated seconds. Decimal GB/MB and Mbit/s. BP means a stake-holding node in a topology that separates BPs from relays.

Traffic includes duplicate bodies plus vote announcements and requests. Sends are recorded when queued; receives when delivered. No TCP/IP framing or other protocols are included. Peaks are the busiest fixed one-second buckets aligned to simulation time zero, not instantaneous or sliding-window link throughput. A per-node send peak sums all its outgoing links.

| Role | Nodes | Sent GB | Received GB | Median sent MB/node | p95 sent MB/node | Max sent MB/node |
|---|---:|---:|---:|---:|---:|---:|
| BP | 458 | 0.537250 | 0.906823 | 1.164 | 1.226 | 1.333 |
| relay | 1042 | 23.852544 | 23.482971 | 19.341 | 39.131 | 109.981 |
| all | 1500 | 24.389794 | 24.389794 | 18.138 | 34.802 | 109.981 |

Percentiles below are across nodes, using each node’s own busiest one-second window. Nodes can peak at different times.

| Role | Median node peak sent Mbit/s | p95 | Max | Median node peak received Mbit/s | p95 | Max |
|---|---:|---:|---:|---:|---:|---:|
| BP | 0.461 | 0.486 | 0.528 | 0.784 | 0.784 | 0.784 |
| relay | 7.607 | 15.475 | 43.552 | 8.449 | 10.147 | 12.125 |
| all | 7.059 | 13.527 | 43.552 | 7.806 | 9.977 | 12.125 |

The [per-node CSV](nodes.csv) includes separate body/control counts, sent/received totals, mean rates, and each peak’s window start. Raw JSON retains every node’s one-second buckets.
