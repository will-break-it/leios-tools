#!/bin/bash
# Replaces the original queue. VD-6 replicated a bounded-fanout result for a
# design direction the VD-1 evidence rules out, so the same wall clock goes to
# replicating the comparison that is actually live: pull against unrestricted
# push at three upstream relays.
set -u
SIM=/Users/will/Workspace/io/leios-tools/.claude/worktrees/vote-diffusion-experiments-74f884/sim-rs
S=/private/tmp/claude-501/-Users-will-Workspace-io-leios-tools--claude-worktrees-vote-diffusion-experiments-74f884/8e25c372-f8a4-4b14-97cc-13346e48ec26/scratchpad
CFG=$S/ev/study-config.yaml
REV=f307ed5fa7077a32eb470ca3832a34092882bfe3
cd "$SIM" || exit 1

while pgrep -f 'vote-diffusion-study\.py' >/dev/null 2>&1; do sleep 20; done
echo "[queue2] vd3-copy finished at $(date -u +%H:%M:%S)"

all_passed() {
  [ -f "$1/runs.csv" ] || return 1
  ! tail -n +2 "$1/runs.csv" | cut -d, -f8 | grep -qv '^passed$'
}
if ! all_passed "$S/vd3-copy"; then
  echo "[queue2] vd3-copy did not pass; stopping"
  cut -d, -f1,8 "$S/vd3-copy/runs.csv" 2>/dev/null
  exit 1
fi

# VD-3 replication: seeds 1 and 2, the two arms the decision rests on. The
# bounded arm is left out; VD-1 shows unprotected caps lose certification and
# the protected variant depends on an out-of-band topology marking.
export VOTE_STUDY_CONFIG_REVISION=$REV VOTE_STUDY_SIZES=1500 \
  VOTE_STUDY_COMMITTEES=top-stake-seats VOTE_STUDY_SLOTS=400 \
  VOTE_STUDY_NODE_TRAFFIC=1 VOTE_STUDY_TRANSPORTS='announce-then-request push' \
  VOTE_STUDY_FANOUTS='all' VOTE_STUDY_FANOUT_PROTECTS_PRODUCERS=false \
  VOTE_STUDY_BP_UPSTREAMS=3 VOTE_STUDY_BP_UPSTREAM_LATENCY=sampled
echo "[queue2] starting vd3-seeds at $(date -u +%H:%M:%S)"
python3 scripts/vote-diffusion-study.py "$CFG" "$S/vd3-seeds" 1 2 \
  >"$S/vd3-seeds.log" 2>&1
echo "[queue2] vd3-seeds exited $? at $(date -u +%H:%M:%S)"
