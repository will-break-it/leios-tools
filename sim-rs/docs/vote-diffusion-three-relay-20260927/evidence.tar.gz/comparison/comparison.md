# Vote diffusion matrix comparison

Wire GB is exact when the matrix captured per-node traffic and the rounded figure from the run log otherwise; the Wire GB exact column says which. 

Peaks are node totals across outgoing links in fixed one-second windows, counted when queued for transmission. They are neither instantaneous nor sliding-window link throughput, and the bandwidth limit applies to each link, not each node.

Q50/Q75/Q95 are quorum availability at nodes holding that share of stake. The certificate threshold is 75% of total voting stake in every row; the quantile varies the observer, not the threshold. Timing means are conditional on attainment and may cover different EBs, so equal counts are not equal identities.

| Matrix | Seed | Nodes | Upstreams | Upstream latency | Transport | Cap | Protect BP | Announce/request B | EBs | Q50 | Q75 | Q95 | Q95 by deadline | Q75 mean s | Q95 mean s | Endorsements | Wire GB | Wire GB exact | Relay median peak Mbit/s | Relay max peak Mbit/s | BP max peak Mbit/s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| published | 0 | 1500 | 2 | sampled | push | 22 | false | 8/8 | 26 | 20/26 | n/a | 0/26 | 0/26 | n/a | n/a | 7 | 19.469734 | true | 7.312 | 7.312 | 0.333 |
| published | 0 | 1500 | 2 | sampled | push | 22 | true | 8/8 | 26 | 20/26 | n/a | 20/26 | 20/26 | n/a | 3.335 | 8 | 19.621395 | true | 7.312 | 7.312 | 0.333 |
| published | 0 | 1500 | 2 | sampled | push | 16 | false | 8/8 | 26 | 0/26 | n/a | 0/26 | 0/26 | n/a | n/a | 1 | 14.194184 | true | 5.318 | 5.318 | 0.299 |
| published | 0 | 1500 | 2 | sampled | push | 16 | true | 8/8 | 26 | 20/26 | n/a | 20/26 | 20/26 | n/a | 3.338 | 8 | 14.375273 | true | 5.318 | 5.318 | 0.333 |
| published | 0 | 1500 | 2 | sampled | push | 8 | false | 8/8 | 26 | 0/26 | n/a | 0/26 | 0/26 | n/a | n/a | 0 | 7.096878 | true | 2.659 | 2.659 | 0.191 |
| published | 0 | 1500 | 2 | sampled | push | 8 | true | 8/8 | 26 | 20/26 | n/a | 20/26 | 20/26 | n/a | 3.345 | 8 | 7.379686 | true | 2.659 | 2.659 | 0.333 |
| published | 0 | 1500 | 2 | sampled | announce-then-request | all | false | 8/8 | 26 | 20/26 | n/a | 20/26 | 20/26 | n/a | 3.850 | 8 | 4.149362 | true | 1.257 | 9.144 | 0.133 |
| published | 0 | 1500 | 2 | sampled | announce-then-request | all | false | 40/40 | 26 | 20/26 | n/a | 20/26 | 20/26 | n/a | 3.850 | 8 | 15.715349 | true | 4.920 | 28.800 | 0.360 |
| published | 0 | 1500 | 2 | sampled | announce-then-request | all | false | 64/64 | 26 | 20/26 | n/a | 20/26 | 20/26 | n/a | 3.850 | 8 | 24.389794 | true | 7.607 | 43.552 | 0.528 |
| published | 0 | 1500 | 2 | sampled | push | all | false | 8/8 | 26 | 20/26 | n/a | 20/26 | 20/26 | n/a | 3.334 | 8 | 32.684092 | true | 10.287 | 60.649 | 0.333 |
| sampled | 0 | 1500 | 3 | sampled | announce-then-request | all | false | 8/8 | 26 | 22/26 | 22/26 | 22/26 | 22/26 | 3.198 | 3.358 | 10 | 4.711820 | true | 1.319 | 10.958 | 0.774 |
| sampled | 0 | 1500 | 3 | sampled | push | all | false | 8/8 | 26 | 22/26 | 22/26 | 22/26 | 22/26 | 3.120 | 3.161 | 10 | 37.334031 | true | 10.654 | 62.716 | 0.688 |
| sampled | 0 | 1500 | 3 | sampled | push | 8 | true | 8/8 | 26 | 22/26 | 22/26 | 22/26 | 22/26 | 3.131 | 3.189 | 10 | 8.696080 | true | 2.749 | 2.749 | 0.688 |
| copy | 0 | 1500 | 3 | copy | announce-then-request | all | false | 8/8 | 26 | 22/26 | 22/26 | 22/26 | 22/26 | 3.143 | 3.221 | 10 | 4.727169 | true | 1.326 | 9.576 | 0.778 |
| copy | 0 | 1500 | 3 | copy | push | all | false | 8/8 | 26 | 22/26 | 22/26 | 22/26 | 22/26 | 3.107 | 3.131 | 10 | 37.446706 | true | 10.677 | 62.857 | 0.690 |
| copy | 0 | 1500 | 3 | copy | push | 8 | true | 8/8 | 26 | 22/26 | 22/26 | 22/26 | 22/26 | 3.116 | 3.142 | 10 | 8.738700 | true | 2.755 | 2.755 | 0.690 |
| seeds | 1 | 1500 | 3 | sampled | announce-then-request | all | false | 8/8 | 24 | 21/24 | 21/24 | 21/24 | 21/24 | 3.198 | 3.359 | 9 | 4.512002 | true | 1.318 | 10.878 | 0.774 |
| seeds | 1 | 1500 | 3 | sampled | push | all | false | 8/8 | 24 | 21/24 | 21/24 | 21/24 | 21/24 | 3.120 | 3.161 | 9 | 35.750568 | true | 10.654 | 62.718 | 0.688 |
| seeds | 2 | 1500 | 3 | sampled | announce-then-request | all | false | 8/8 | 22 | 19/22 | 19/22 | 19/22 | 19/22 | 3.198 | 3.358 | 9 | 4.079367 | true | 1.316 | 10.917 | 0.774 |
| seeds | 2 | 1500 | 3 | sampled | push | all | false | 8/8 | 22 | 19/22 | 19/22 | 19/22 | 19/22 | 3.120 | 3.161 | 9 | 32.322453 | true | 10.654 | 62.712 | 0.688 |
