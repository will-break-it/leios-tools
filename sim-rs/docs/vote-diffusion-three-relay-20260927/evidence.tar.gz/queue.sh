#!/bin/bash
# Sequential queue: simulations must not overlap or they contend for CPU and
# distort the timing measurements they exist to produce.
set -u
SIM=/Users/will/Workspace/io/leios-tools/.claude/worktrees/vote-diffusion-experiments-74f884/sim-rs
S=/private/tmp/claude-501/-Users-will-Workspace-io-leios-tools--claude-worktrees-vote-diffusion-experiments-74f884/8e25c372-f8a4-4b14-97cc-13346e48ec26/scratchpad
CFG=$S/ev/study-config.yaml
REV=f307ed5fa7077a32eb470ca3832a34092882bfe3
cd "$SIM" || exit 1

wait_for_runner() {
  while pgrep -f 'vote-diffusion-study\.py' >/dev/null 2>&1; do sleep 20; done
}

all_passed() {  # $1 = run directory
  [ -f "$1/runs.csv" ] || return 1
  ! tail -n +2 "$1/runs.csv" | cut -d, -f8 | grep -qv '^passed$'
}

echo "[queue] waiting for the running matrix to finish"
wait_for_runner
if ! all_passed "$S/vd3-a"; then
  echo "[queue] vd3-a did not pass; stopping so the failure is not buried"
  cut -d, -f1,8 "$S/vd3-a/runs.csv" 2>/dev/null
  exit 1
fi
echo "[queue] vd3-a passed"

run() {  # $1 = output dir, rest = env assignments already exported
  echo "[queue] starting $1 at $(date -u +%H:%M:%S)"
  python3 scripts/vote-diffusion-study.py "$CFG" "$1" "${SEEDS[@]}" \
    >"$1.log" 2>&1
  local status=$?
  echo "[queue] $1 exited $status at $(date -u +%H:%M:%S)"
  return $status
}

# VD-3 companion: the co-located third relay, bracketing the sampled latency.
export VOTE_STUDY_CONFIG_REVISION=$REV VOTE_STUDY_SIZES=1500 \
  VOTE_STUDY_COMMITTEES=top-stake-seats VOTE_STUDY_SLOTS=400 \
  VOTE_STUDY_NODE_TRAFFIC=1 VOTE_STUDY_TRANSPORTS='announce-then-request push' \
  VOTE_STUDY_FANOUTS='all 8' VOTE_STUDY_FANOUT_PROTECTS_PRODUCERS=true \
  VOTE_STUDY_BP_UPSTREAMS=3 VOTE_STUDY_BP_UPSTREAM_LATENCY=copy
SEEDS=(0)
run "$S/vd3-copy" || exit 1

# VD-6: replicate the BP-protection result on seeds 1 and 2 at the recommended
# cap. Unprotected arms first, so the protected comparison has its baseline.
unset VOTE_STUDY_BP_UPSTREAMS VOTE_STUDY_BP_UPSTREAM_LATENCY
export VOTE_STUDY_TRANSPORTS=push VOTE_STUDY_FANOUTS='all 8' \
  VOTE_STUDY_FANOUT_PROTECTS_PRODUCERS=false
SEEDS=(1 2)
run "$S/vd6-unprotected" || exit 1

export VOTE_STUDY_FANOUTS='8' VOTE_STUDY_FANOUT_PROTECTS_PRODUCERS=true
run "$S/vd6-protected" || exit 1

echo "[queue] all matrices finished at $(date -u +%H:%M:%S)"
